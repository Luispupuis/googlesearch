package de.luispupuis.goggleseacrch;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class searchcmd implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String surl = "https://www.google.de/search?q=";
        String url = "https://www.google.de/";
        if(args.length == 1){
            String msgf = args[0];
            String msg = msgf.replace(" ", "+");
            Player p = (Player) sender;
            p.sendMessage("§6§lLuispupuis»§b§l Hier ist dein Ergebnis für§e" + msgf + "§a§l " + surl + msg);
        }


        return false;
    }
}
