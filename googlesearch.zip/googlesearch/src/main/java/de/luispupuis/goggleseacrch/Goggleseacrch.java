package de.luispupuis.goggleseacrch;

import org.bukkit.plugin.java.JavaPlugin;

public final class Goggleseacrch extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
         getCommand("googlesearch").setExecutor(new searchcmd());
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
